package com.example.madfinal;

public class GlobalVariable {
    public static String message;
}
